SIMPLE EXAM APP BY SOUROV — ANDROID APK PROJECT

এই প্রজেক্ট থেকে ফ্রি-তে APK তৈরি করা যাবে GitHub Actions দিয়ে।

গুরুত্বপূর্ণ:
- APK-টি তোমার বর্তমান Netlify ওয়েব অ্যাপ খুলবে।
- এখানে URL দেওয়া আছে: https://glittery-pastelito-8fcca6.netlify.app/
- Netlify-তে ওয়েব অ্যাপ আপডেট করলে APK নতুন করে ইনস্টল না করেও অনলাইনে নতুন কনটেন্ট দেখাবে।
- এটি প্রথমবারের জন্য debug-signed APK; Play Store release-এর জন্য নয়।

APK তৈরির ধাপ:
1. GitHub-এ নতুন repository তৈরি করো (যেমন SimpleExamAndroid)।
2. এই ZIP Extract করে ভেতরের সব ফাইল repository-তে Upload করো।
3. Commit changes করো।
4. Repository-র Actions tab খোলো।
5. Build Simple Exam App APK workflow শেষ হওয়া পর্যন্ত অপেক্ষা করো।
6. Actions-এর সফল run খুলে নিচের Artifacts থেকে Simple-Exam-App-APK ডাউনলোড করো।
7. ZIP extract করে app-debug.apk ফোনে নামাও এবং ইনস্টল করো।

প্রথমবার Android-এ অজানা উৎস থেকে অ্যাপ ইনস্টলের অনুমতি চাইতে পারে। কেবল নিজের তৈরি এই APK-টির জন্য প্রয়োজন হলে অনুমতি দেবে।

যদি তোমার Netlify URL বদলে গিয়ে থাকে, app/src/main/java/com/sourov/simpleexam/MainActivity.java ফাইলে APP_URL পরিবর্তন করতে হবে।
